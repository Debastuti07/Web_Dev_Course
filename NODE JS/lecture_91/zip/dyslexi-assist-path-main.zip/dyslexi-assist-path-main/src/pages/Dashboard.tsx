import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { User, Session } from "@supabase/supabase-js";
import { 
  BookOpen, 
  Brain, 
  Volume2, 
  Gamepad2, 
  BarChart3, 
  Camera,
  Play,
  PenTool,
  LogOut,
  Settings,
  Heart,
  Star,
  Award,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [assessmentCompleted, setAssessmentCompleted] = useState(false);
  const [checkingAssessment, setCheckingAssessment] = useState(true);
  const [userStats, setUserStats] = useState({
    daysActive: 0,
    exercisesDone: 0,
    achievements: 0,
    weeklyProgress: 0
  });
  const [achievementStats, setAchievementStats] = useState<any>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Define comprehensive achievement system
  const achievements = [
    // Assessment Milestones
    { id: 1, name: "First Step", description: "Complete your first assessment", requirement: (stats: any) => stats.exercisesDone >= 1 },
    { id: 2, name: "Getting Started", description: "Complete 3 assessments", requirement: (stats: any) => stats.exercisesDone >= 3 },
    { id: 3, name: "Assessment Complete", description: "Complete all 4 basic assessments", requirement: (stats: any) => stats.exercisesDone >= 4 },
    { id: 4, name: "Dedicated Learner", description: "Complete 10 assessments", requirement: (stats: any) => stats.exercisesDone >= 10 },
    { id: 5, name: "Assessment Expert", description: "Complete 25 assessments", requirement: (stats: any) => stats.exercisesDone >= 25 },
    { id: 6, name: "Test Master", description: "Complete 50 assessments", requirement: (stats: any) => stats.exercisesDone >= 50 },

    // Score-Based Achievements
    { id: 7, name: "Good Start", description: "Score 50% or higher on any test", requirement: (stats: any) => stats.maxScore >= 50 },
    { id: 8, name: "Great Progress", description: "Score 60% or higher on any test", requirement: (stats: any) => stats.maxScore >= 60 },
    { id: 9, name: "Well Done", description: "Score 70% or higher on any test", requirement: (stats: any) => stats.maxScore >= 70 },
    { id: 10, name: "Excellent Work", description: "Score 80% or higher on any test", requirement: (stats: any) => stats.maxScore >= 80 },
    { id: 11, name: "Outstanding", description: "Score 90% or higher on any test", requirement: (stats: any) => stats.maxScore >= 90 },
    { id: 12, name: "Perfect Score", description: "Score 100% on any test", requirement: (stats: any) => stats.maxScore >= 100 },

    // Average Score Achievements
    { id: 13, name: "Consistent Performer", description: "Maintain 60% average across all tests", requirement: (stats: any) => stats.avgScore >= 60 },
    { id: 14, name: "Strong Learner", description: "Maintain 70% average across all tests", requirement: (stats: any) => stats.avgScore >= 70 },
    { id: 15, name: "Advanced Student", description: "Maintain 80% average across all tests", requirement: (stats: any) => stats.avgScore >= 80 },
    { id: 16, name: "Academic Excellence", description: "Maintain 90% average across all tests", requirement: (stats: any) => stats.avgScore >= 90 },

    // Consistency Achievements
    { id: 17, name: "Daily Dedication", description: "Practice for 2 consecutive days", requirement: (stats: any) => stats.daysActive >= 2 },
    { id: 18, name: "Weekly Warrior", description: "Practice for 7 different days", requirement: (stats: any) => stats.daysActive >= 7 },
    { id: 19, name: "Monthly Marvel", description: "Practice for 15 different days", requirement: (stats: any) => stats.daysActive >= 15 },
    { id: 20, name: "Consistent Champion", description: "Practice for 30 different days", requirement: (stats: any) => stats.daysActive >= 30 },

    // Speed Achievements
    { id: 21, name: "Quick Thinker", description: "Complete a test in under 2 minutes", requirement: (stats: any) => stats.fastestTime <= 120 },
    { id: 22, name: "Lightning Fast", description: "Complete a test in under 1 minute", requirement: (stats: any) => stats.fastestTime <= 60 },
    { id: 23, name: "Speed Demon", description: "Complete a test in under 30 seconds", requirement: (stats: any) => stats.fastestTime <= 30 },

    // Test Type Specific
    { id: 24, name: "Reading Champion", description: "Excel in Reading Comprehension tests", requirement: (stats: any) => stats.readingTests >= 5 },
    { id: 25, name: "Phonics Pro", description: "Complete 5 Phonological Processing tests", requirement: (stats: any) => stats.phonicsTests >= 5 },
    { id: 26, name: "Naming Master", description: "Complete 5 Rapid Naming tests", requirement: (stats: any) => stats.namingTests >= 5 },
    { id: 27, name: "Memory Expert", description: "Complete 5 Working Memory tests", requirement: (stats: any) => stats.memoryTests >= 5 },

    // Improvement Achievements
    { id: 28, name: "Getting Better", description: "Improve your score by 10 points", requirement: (stats: any) => stats.improvement >= 10 },
    { id: 29, name: "Great Improvement", description: "Improve your score by 20 points", requirement: (stats: any) => stats.improvement >= 20 },
    { id: 30, name: "Amazing Progress", description: "Improve your score by 30 points", requirement: (stats: any) => stats.improvement >= 30 },
    { id: 31, name: "Remarkable Growth", description: "Improve your score by 50 points", requirement: (stats: any) => stats.improvement >= 50 },

    // Special Milestones
    { id: 32, name: "Explorer", description: "Try all 4 different test types", requirement: (stats: any) => stats.testTypes >= 4 },
    { id: 33, name: "Determined", description: "Come back after a break", requirement: (stats: any) => stats.comeback === true },
    { id: 34, name: "Early Bird", description: "Complete a test before 9 AM", requirement: (stats: any) => stats.earlyBird === true },
    { id: 35, name: "Night Owl", description: "Complete a test after 9 PM", requirement: (stats: any) => stats.nightOwl === true },

    // Advanced Learning
    { id: 36, name: "Scholar", description: "Complete 3 tests in one day", requirement: (stats: any) => stats.maxTestsPerDay >= 3 },
    { id: 37, name: "Intensive Learner", description: "Complete 5 tests in one day", requirement: (stats: any) => stats.maxTestsPerDay >= 5 },
    { id: 38, name: "Study Marathon", description: "Complete 10 tests in one day", requirement: (stats: any) => stats.maxTestsPerDay >= 10 },

    // Mastery Levels
    { id: 39, name: "Apprentice", description: "Reach Level 2 in learning", requirement: (stats: any) => stats.level >= 2 },
    { id: 40, name: "Skilled", description: "Reach Level 5 in learning", requirement: (stats: any) => stats.level >= 5 },
    { id: 41, name: "Expert", description: "Reach Level 10 in learning", requirement: (stats: any) => stats.level >= 10 },
    { id: 42, name: "Master", description: "Reach Level 20 in learning", requirement: (stats: any) => stats.level >= 20 },
    { id: 43, name: "Grandmaster", description: "Reach Level 50 in learning", requirement: (stats: any) => stats.level >= 50 },

    // Milestone Achievements
    { id: 44, name: "Century Club", description: "Complete 100 assessments", requirement: (stats: any) => stats.exercisesDone >= 100 },
    { id: 45, name: "Double Century", description: "Complete 200 assessments", requirement: (stats: any) => stats.exercisesDone >= 200 },
    { id: 46, name: "Triple Century", description: "Complete 300 assessments", requirement: (stats: any) => stats.exercisesDone >= 300 },

    // Time-based Achievements
    { id: 47, name: "One Month Strong", description: "Practice for 30 days", requirement: (stats: any) => stats.totalDays >= 30 },
    { id: 48, name: "Two Month Champion", description: "Practice for 60 days", requirement: (stats: any) => stats.totalDays >= 60 },
    { id: 49, name: "Quarter Year Hero", description: "Practice for 90 days", requirement: (stats: any) => stats.totalDays >= 90 },
    { id: 50, name: "Half Year Legend", description: "Practice for 180 days", requirement: (stats: any) => stats.totalDays >= 180 },
    { id: 51, name: "One Year Master", description: "Practice for 365 days", requirement: (stats: any) => stats.totalDays >= 365 },

    // Special Recognition
    { id: 52, name: "Perfectionist", description: "Score 100% on 3 different tests", requirement: (stats: any) => stats.perfectScores >= 3 },
    { id: 53, name: "All-Rounder", description: "Score 80%+ on all test types", requirement: (stats: any) => stats.allRounder === true },
    { id: 54, name: "Learning Legend", description: "Unlock 25 achievements", requirement: (stats: any) => stats.achievementCount >= 25 },
    { id: 55, name: "Ultimate Scholar", description: "Unlock all available achievements", requirement: (stats: any) => stats.achievementCount >= 54 }
  ];

  // Calculate user statistics
  const calculateUserStats = async (userId: string) => {
    try {
      const { data: assessmentResults } = await supabase
        .from('assessment_results')
        .select('*')
        .eq('user_id', userId);

      if (assessmentResults && assessmentResults.length > 0) {
        // Basic stats
        const uniqueDays = new Set(
          assessmentResults.map(result => 
            new Date(result.created_at).toDateString()
          )
        );
        const daysActive = uniqueDays.size;
        const exercisesDone = assessmentResults.length;

        // Score calculations
        const scores = assessmentResults.map(r => r.score);
        const maxScore = Math.max(...scores);
        const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;
        const perfectScores = scores.filter(s => s >= 100).length;

        // Time calculations
        const times = assessmentResults.map(r => r.time_spent);
        const fastestTime = Math.min(...times);

        // Test type counts
        const testTypeCounts = assessmentResults.reduce((acc: any, result) => {
          acc[result.test_type] = (acc[result.test_type] || 0) + 1;
          return acc;
        }, {});

        const readingTests = testTypeCounts['reading-comprehension'] || 0;
        const phonicsTests = testTypeCounts['phonological-processing'] || 0;
        const namingTests = testTypeCounts['rapid-naming'] || 0;
        const memoryTests = testTypeCounts['working-memory'] || 0;
        const testTypes = Object.keys(testTypeCounts).length;

        // Improvement calculation (difference between latest and first score)
        const sortedResults = assessmentResults.sort((a, b) => 
          new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        );
        const improvement = sortedResults.length > 1 ? 
          sortedResults[sortedResults.length - 1].score - sortedResults[0].score : 0;

        // Daily activity analysis
        const testsPerDay = Array.from(uniqueDays).map(day => 
          assessmentResults.filter(result => 
            new Date(result.created_at).toDateString() === day
          ).length
        );
        const maxTestsPerDay = Math.max(...testsPerDay, 0);

        // Time-based checks
        const times_of_day = assessmentResults.map(r => new Date(r.created_at).getHours());
        const earlyBird = times_of_day.some(hour => hour < 9);
        const nightOwl = times_of_day.some(hour => hour >= 21);

        // Level calculation (based on total exercises)
        const level = Math.floor(exercisesDone / 5) + 1;

        // Days since first assessment
        const firstAssessment = new Date(Math.min(...assessmentResults.map(r => new Date(r.created_at).getTime())));
        const totalDays = Math.floor((Date.now() - firstAssessment.getTime()) / (1000 * 60 * 60 * 24));

        // All-rounder check (80%+ average in each test type)
        const allRounder = Object.keys(testTypeCounts).length >= 4 && 
          Object.keys(testTypeCounts).every(type => {
            const typeResults = assessmentResults.filter(r => r.test_type === type);
            const typeAvg = typeResults.reduce((sum, r) => sum + r.score, 0) / typeResults.length;
            return typeAvg >= 80;
          });

        // Comeback check (gap of more than 7 days between assessments)
        const comeback = sortedResults.some((result, index) => {
          if (index === 0) return false;
          const prevDate = new Date(sortedResults[index - 1].created_at);
          const currDate = new Date(result.created_at);
          const daysDiff = (currDate.getTime() - prevDate.getTime()) / (1000 * 60 * 60 * 24);
          return daysDiff > 7;
        });

        const stats = {
          daysActive,
          exercisesDone,
          maxScore,
          avgScore,
          perfectScores,
          fastestTime,
          readingTests,
          phonicsTests,
          namingTests,
          memoryTests,
          testTypes,
          improvement,
          maxTestsPerDay,
          earlyBird,
          nightOwl,
          level,
          totalDays,
          allRounder,
          comeback,
          achievementCount: 0 // Will be calculated below
        };

        // Calculate achievements
        const unlockedAchievements = achievements.filter(achievement => 
          achievement.requirement({ ...stats, achievementCount: 0 })
        );
        stats.achievementCount = unlockedAchievements.length;

        // Recalculate with correct achievement count for meta-achievements
        const finalUnlockedAchievements = achievements.filter(achievement => 
          achievement.requirement(stats)
        );

        // Calculate weekly progress
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
        const recentAssessments = assessmentResults.filter(
          result => new Date(result.created_at) >= oneWeekAgo
        );
        const weeklyProgress = Math.min((recentAssessments.length / 10) * 100, 100);

        setUserStats({
          daysActive,
          exercisesDone,
          achievements: finalUnlockedAchievements.length,
          weeklyProgress
        });

        // Store detailed stats for achievements modal
        setAchievementStats({
          ...stats,
          unlockedAchievements: finalUnlockedAchievements
        });
      } else {
        setUserStats({
          daysActive: 0,
          exercisesDone: 0,
          achievements: 0,
          weeklyProgress: 0
        });
      }
    } catch (error) {
      console.error('Error calculating user stats:', error);
    }
  };

  // Check assessment completion
  const checkAssessmentCompletion = async (userId: string) => {
    try {
      const { data: assessmentResults } = await supabase
        .from('assessment_results')
        .select('test_type')
        .eq('user_id', userId);

      const hasCompletedAllTests = assessmentResults && assessmentResults.length >= 4;
      setAssessmentCompleted(hasCompletedAllTests);
      setCheckingAssessment(false);

      // Calculate stats regardless of completion status
      await calculateUserStats(userId);

      if (!hasCompletedAllTests) {
        toast({
          title: "Assessment Required",
          description: "Please complete your dyslexia assessment to access the dashboard",
          variant: "destructive"
        });
        navigate('/assessment');
      }
    } catch (error) {
      console.error('Error checking assessment:', error);
      setCheckingAssessment(false);
    }
  };

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (!session && event === 'SIGNED_OUT') {
          navigate('/auth');
        } else if (session?.user) {
          checkAssessmentCompletion(session.user.id);
        }
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
      
      if (!session) {
        navigate('/auth');
      } else {
        checkAssessmentCompletion(session.user.id);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Signed out successfully",
        description: "See you soon! 👋",
      });
      navigate('/auth');
    } catch (error) {
      toast({
        title: "Error signing out",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-gradient-primary rounded-2xl mx-auto animate-pulse-soft flex items-center justify-center">
            <BookOpen className="w-8 h-8 text-primary-foreground" />
          </div>
          <p className="text-muted-foreground text-dyslexic">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const features = [
    {
      title: "Dyslexia Assessment",
      description: "Take comprehensive tests to understand your learning profile",
      icon: Brain,
      color: "bg-gradient-primary",
      href: "/assessment",
      variant: "default" as const,
      progress: 0
    },
    {
      title: "Text-to-Speech Reader",
      description: "Listen to any text content with our friendly voice reader",
      icon: Volume2,
      color: "bg-gradient-warm",
      href: "/text-to-speech",
      variant: "secondary" as const,
      progress: 0
    },
    {
      title: "Learning Games",
      description: "Fun and engaging games designed for dyslexic learners",
      icon: Gamepad2,
      color: "bg-gradient-success",
      href: "/games",
      variant: "success" as const,
      progress: 0
    },
    {
      title: "Reading Progress",
      description: "Track your reading improvement over time",
      icon: BarChart3,
      color: "bg-primary-soft",
      href: "/progress",
      variant: "gentle" as const,
      progress: 25
    },
    {
      title: "Image Text Reader",
      description: "Extract and read text from images instantly",
      icon: Camera,
      color: "bg-secondary-warm",
      href: "/image-reader",
      variant: "playful" as const,
      progress: 0
    },
    {
      title: "Video Lessons",
      description: "Watch educational videos designed for dyslexic learners",
      icon: Play,
      color: "bg-gradient-secondary",
      href: "/video-lessons",
      variant: "accent" as const,
      progress: 0
    },
    {
      title: "Notes & Mistakes",
      description: "Track your learning progress and record mistakes",
      icon: PenTool,
      color: "bg-gradient-accent",
      href: "/notes",
      variant: "premium" as const,
      progress: 0
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
                <BookOpen className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                  Welcome back, {user?.user_metadata?.name || 'Learner'}! 
                </h1>
                <p className="text-muted-foreground text-dyslexic">
                  Ready for another amazing learning adventure? 🌟
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon">
              <Settings className="w-5 h-5" />
            </Button>
            <Button 
              variant="outline" 
              onClick={handleSignOut}
              className="gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>
        </div>

        {/* Progress Overview */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Award className="w-6 h-6 text-primary" />
              <CardTitle className="font-display">Your Learning Journey</CardTitle>
            </div>
            <CardDescription className="text-dyslexic">
              You're making great progress! Keep up the wonderful work.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-primary-soft rounded-xl">
                <div className="text-2xl font-display font-bold text-primary">{userStats.daysActive}</div>
                <div className="text-sm text-primary text-dyslexic">Days Active</div>
              </div>
              <div className="text-center p-4 bg-success-soft rounded-xl">
                <div className="text-2xl font-display font-bold text-success">{userStats.exercisesDone}</div>
                <div className="text-sm text-success text-dyslexic">Exercises Done</div>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <div className="text-center p-4 bg-secondary rounded-xl cursor-pointer hover:bg-secondary/80 transition-colors">
                    <div className="text-2xl font-display font-bold text-secondary-foreground">{userStats.achievements}</div>
                    <div className="text-sm text-secondary-foreground text-dyslexic">Achievements</div>
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Award className="w-6 h-6 text-primary" />
                      Your Achievements
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6">
                    {/* Achieved Milestones */}
                    <div>
                      <h3 className="text-lg font-semibold text-success mb-3 flex items-center gap-2">
                        <CheckCircle className="w-5 h-5" />
                        Unlocked Achievements ({achievementStats?.unlockedAchievements?.length || 0})
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {achievementStats?.unlockedAchievements?.map((achievement: any) => (
                          <div 
                            key={achievement.id}
                            className="p-4 bg-success-soft border border-success rounded-lg"
                          >
                            <div className="flex items-start gap-3">
                              <CheckCircle className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                              <div>
                                <h4 className="font-semibold text-success">{achievement.name}</h4>
                                <p className="text-sm text-success/80">{achievement.description}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      {achievementStats?.unlockedAchievements?.length === 0 && (
                        <p className="text-muted-foreground text-center py-8">
                          Complete your first assessment to start earning achievements!
                        </p>
                      )}
                    </div>

                    {/* Remaining Milestones */}
                    <div>
                      <h3 className="text-lg font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                        <AlertCircle className="w-5 h-5" />
                        Upcoming Achievements ({achievements.length - (achievementStats?.unlockedAchievements?.length || 0)})
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {achievements
                          .filter(achievement => !achievementStats?.unlockedAchievements?.some((unlocked: any) => unlocked.id === achievement.id))
                          .map((achievement) => (
                            <div 
                              key={achievement.id}
                              className="p-4 bg-muted/50 border border-border rounded-lg opacity-75"
                            >
                              <div className="flex items-start gap-3">
                                <AlertCircle className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                                <div>
                                  <h4 className="font-semibold text-foreground">{achievement.name}</h4>
                                  <p className="text-sm text-muted-foreground">{achievement.description}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-dyslexic">Weekly Goal Progress</span>
                <span className="font-semibold">{Math.round((userStats.weeklyProgress / 100) * 10)}/10 exercises</span>
              </div>
              <Progress value={userStats.weeklyProgress} className="h-3" />
            </div>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={feature.title}
              className="shadow-medium border-2 border-primary/10 hover:shadow-strong transition-all duration-300 hover:scale-105 group"
            >
              <CardHeader className="text-center pb-4">
                <div className={`w-16 h-16 ${feature.color} rounded-2xl mx-auto flex items-center justify-center shadow-medium group-hover:shadow-glow transition-all duration-300 animate-float`} 
                     style={{ animationDelay: `${index * 0.2}s` }}>
                  <feature.icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="font-display text-lg">
                  {feature.title}
                </CardTitle>
                <CardDescription className="text-dyslexic">
                  {feature.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {feature.progress > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-semibold">{feature.progress}%</span>
                    </div>
                    <Progress value={feature.progress} className="h-2" />
                  </div>
                )}
                
                <Button 
                  className="w-full group-hover:scale-105 transition-transform duration-200"
                  variant={feature.variant}
                  size="lg"
                  onClick={() => navigate(feature.href)}
                >
                  Get Started
                  <Star className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Motivational Footer */}
        <Card className="bg-gradient-primary text-primary-foreground shadow-glow border-0">
          <CardContent className="text-center p-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Heart className="w-6 h-6" />
              <span className="text-xl font-display font-bold">You're Amazing!</span>
              <Heart className="w-6 h-6" />
            </div>
            <p className="text-lg text-dyslexic opacity-90">
              Every small step counts towards your big dreams. Keep learning, keep growing! 
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;