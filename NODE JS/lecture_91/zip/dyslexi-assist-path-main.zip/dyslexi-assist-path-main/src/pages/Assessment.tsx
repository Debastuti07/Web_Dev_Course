import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { ArrowLeft, Brain, Clock, Mic, Eye, BookOpen, CheckCircle, Play, Square, RotateCcw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

type TestType = 'phonological' | 'rapid-naming' | 'working-memory' | 'reading-fluency';

interface TestResult {
  type: TestType;
  score: number;
  timeSpent: number;
  completed: boolean;
}

interface TestState {
  isActive: boolean;
  currentQuestion: number;
  userAnswers: string[];
  correctAnswers: number;
  startTime: number;
  questions?: any[]; // Store generated questions
}

const Assessment = () => {
  const [currentTest, setCurrentTest] = useState<TestType | null>(null);
  const [results, setResults] = useState<TestResult[]>([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [testState, setTestState] = useState<TestState>({
    isActive: false,
    currentQuestion: 0,
    userAnswers: [],
    correctAnswers: 0,
    startTime: 0,
    questions: []
  });
  const [userInput, setUserInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [sequenceShown, setSequenceShown] = useState(false);
  const [currentSequence, setCurrentSequence] = useState<number[]>([]);
  const [showingSequence, setShowingSequence] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Check if user has completed assessment
  useEffect(() => {
    checkAssessmentStatus();
  }, []);

  const checkAssessmentStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }

      const { data: assessmentResults } = await supabase
        .from('assessment_results')
        .select('*')
        .eq('user_id', user.id);

      if (assessmentResults && assessmentResults.length >= 4) {
        // User has completed all tests, allow dashboard access
        const savedResults = assessmentResults.map(result => ({
          type: result.test_type as TestType,
          score: result.score,
          timeSpent: result.time_spent,
          completed: true
        }));
        setResults(savedResults);
      }
    } catch (error) {
      console.error('Error checking assessment status:', error);
    }
  };

  const saveResultToDatabase = async (result: TestResult) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('assessment_results')
        .insert({
          user_id: user.id,
          test_type: result.type,
          score: result.score,
          time_spent: result.timeSpent
        });

      if (error) {
        console.error('Error saving result:', error);
        toast({
          title: "Error",
          description: "Failed to save test result. Please try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error saving result:', error);
    }
  };

  const tests = [
    {
      id: 'phonological' as TestType,
      title: 'Phonological Processing Test',
      description: 'Find rhyming words within the time limit',
      icon: Brain,
      color: 'bg-gradient-primary',
      time: 60,
      instructions: 'Type a word that rhymes with each given word. You have 60 seconds.',
      questions: ['CAT', 'SUN', 'TREE', 'BALL', 'FISH'] // Fixed words for now
    },
    {
      id: 'rapid-naming' as TestType,
      title: 'Rapid Naming Test',
      description: 'Name objects as quickly as possible',
      icon: Eye,
      color: 'bg-gradient-warm',
      time: 30,
      instructions: 'Type the name of each object shown. You have 30 seconds.',
      questions: ['🐱', '🚗', '⭐', '🏠', '🌺'] // Fixed objects for now
    },
    {
      id: 'working-memory' as TestType,
      title: 'Working Memory Assessment',
      description: 'Remember and repeat sequences',
      icon: Clock,
      color: 'bg-gradient-success',
      time: 45,
      instructions: 'Remember the number sequences and type them back exactly.',
      questions: [
        [3, 7, 1],
        [5, 2, 9, 4],
        [8, 1, 6, 3, 5],
        [2, 9, 4, 7, 1, 8],
        [6, 3, 9, 1, 5, 7, 2]
      ]
    },
    {
      id: 'reading-fluency' as TestType,
      title: 'Reading Fluency Analysis',
      description: 'Read passages and answer comprehension questions',
      icon: BookOpen,
      color: 'bg-secondary-warm',
      time: 120,
      instructions: 'Read each passage and answer the question that follows.',
      questions: [
        {
          passage: "The sun was shining brightly in the clear blue sky. Birds were singing in the trees, and children were playing happily in the park.",
          question: "What were the children doing?",
          answer: "playing"
        },
        {
          passage: "Maria loved to read books every evening before bed. She had a large collection of fantasy novels on her bookshelf.",
          question: "When did Maria like to read?",
          answer: "evening"
        }
      ]
    }
  ];

  const getCompletedCount = () => {
    return results.filter(r => r.completed).length;
  };

  const getOverallProgress = () => {
    return (getCompletedCount() / tests.length) * 100;
  };

  const getDyslexiaLevel = () => {
    if (results.length < tests.length) return null;
    
    const avgScore = results.reduce((sum, r) => sum + r.score, 0) / results.length;
    
    if (avgScore >= 85) return { level: 'Very Low', severity: 1, color: 'text-success' };
    if (avgScore >= 70) return { level: 'Low', severity: 2, color: 'text-success' };
    if (avgScore >= 50) return { level: 'Medium', severity: 3, color: 'text-warning' };
    if (avgScore >= 30) return { level: 'High', severity: 4, color: 'text-destructive' };
    return { level: 'Very High', severity: 5, color: 'text-destructive' };
  };

  const startTest = (testType: TestType) => {
    const test = tests.find(t => t.id === testType);
    if (!test) return;

    // Generate random questions only when test starts
    let testQuestions = test.questions;
    if (testType === 'phonological') {
      const phoneticWords = ['CAT', 'SUN', 'TREE', 'BALL', 'FISH', 'DOG', 'RAIN', 'CAKE', 'BOOK', 'STAR', 'MOON', 'BIRD', 'SHIP', 'RING', 'CLOUD'];
      testQuestions = phoneticWords.sort(() => Math.random() - 0.5).slice(0, 5);
    } else if (testType === 'rapid-naming') {
      const objects = ['🐱', '🚗', '⭐', '🏠', '🌺', '🐶', '🍎', '📱', '⚽', '🎨', '🌙', '🔥', '🎸', '🏀', '🌲'];
      testQuestions = objects.sort(() => Math.random() - 0.5).slice(0, 5);
    }

    setCurrentTest(testType);
    setTimeLeft(test.time);
    setTestState({
      isActive: true,
      currentQuestion: 0,
      userAnswers: [],
      correctAnswers: 0,
      startTime: Date.now(),
      questions: testQuestions // Store the generated questions in test state
    });
    setUserInput("");
    
    toast({
      title: `Starting ${test.title}`,
      description: test.instructions,
    });

    // Start timer
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          endTest();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // For working memory test, show first sequence
    if (testType === 'working-memory') {
      showSequence(0);
    }
  };

  const showSequence = (questionIndex: number) => {
    const test = tests.find(t => t.id === 'working-memory');
    if (!test || !test.questions) return;

    const sequence = test.questions[questionIndex] as number[];
    setCurrentSequence(sequence);
    setShowingSequence(true);
    setSequenceShown(false);

    // Show sequence for 3 seconds
    setTimeout(() => {
      setShowingSequence(false);
      setSequenceShown(true);
    }, 3000);
  };

  const submitAnswer = () => {
    if (!currentTest || !userInput.trim()) return;

    const test = tests.find(t => t.id === currentTest);
    if (!test) return;

    const newAnswers = [...testState.userAnswers, userInput.trim()];
    let isCorrect = false;

    // Check answer based on test type
    switch (currentTest) {
      case 'phonological':
        // Use questions from test state instead of test definition
        const word = testState.questions![testState.currentQuestion] as string;
        isCorrect = checkRhyme(word.toLowerCase(), userInput.toLowerCase());
        break;
      case 'rapid-naming':
        const object = testState.questions![testState.currentQuestion] as string;
        isCorrect = checkObjectName(object, userInput.toLowerCase());
        break;
      case 'working-memory':
        const sequence = test.questions![testState.currentQuestion] as number[];
        isCorrect = userInput.replace(/[^0-9]/g, '') === sequence.join('');
        break;
      case 'reading-fluency':
        const questionData = test.questions![testState.currentQuestion] as any;
        isCorrect = userInput.toLowerCase().includes(questionData.answer.toLowerCase());
        break;
    }

    const newCorrectAnswers = testState.correctAnswers + (isCorrect ? 1 : 0);
    const nextQuestion = testState.currentQuestion + 1;

    // Show immediate feedback
    if (isCorrect) {
      toast({
        title: "Correct! ✅",
        description: `Great job! Score: ${newCorrectAnswers}/${nextQuestion}`,
      });
    } else {
      toast({
        title: "Keep trying! 💪",
        description: `Score: ${newCorrectAnswers}/${nextQuestion}`,
        variant: "destructive"
      });
    }

    setTestState(prev => ({
      ...prev,
      userAnswers: newAnswers,
      correctAnswers: newCorrectAnswers,
      currentQuestion: nextQuestion
    }));

    setUserInput("");

    // Check if test is complete
    const totalQuestions = currentTest === 'phonological' || currentTest === 'rapid-naming' 
      ? testState.questions!.length 
      : test.questions!.length;
      
    if (nextQuestion >= totalQuestions) {
      endTest();
    } else if (currentTest === 'working-memory') {
      // Show next sequence
      showSequence(nextQuestion);
    }
  };

  const checkRhyme = (word1: string, word2: string): boolean => {
    // Enhanced rhyme patterns with more words and flexible matching
    const rhymes: Record<string, string[]> = {
      'cat': ['bat', 'hat', 'mat', 'rat', 'fat', 'sat', 'chat', 'flat', 'that', 'pat'],
      'sun': ['run', 'fun', 'gun', 'bun', 'ton', 'won', 'done', 'one', 'none', 'son'],
      'tree': ['free', 'see', 'bee', 'key', 'tea', 'sea', 'me', 'we', 'three', 'knee'],
      'ball': ['call', 'wall', 'tall', 'fall', 'hall', 'all', 'small', 'mall', 'doll', 'poll'],
      'fish': ['dish', 'wish', 'rich', 'which', 'witch', 'switch', 'stitch', 'pitch', 'ditch', 'hitch'],
      'dog': ['log', 'fog', 'bog', 'hog', 'jog', 'clog', 'frog', 'blog', 'smog', 'cog'],
      'rain': ['pain', 'gain', 'main', 'brain', 'train', 'plain', 'chain', 'strain', 'drain', 'stain'],
      'cake': ['make', 'take', 'lake', 'wake', 'bake', 'fake', 'shake', 'brake', 'snake', 'rake'],
      'book': ['look', 'cook', 'took', 'hook', 'brook', 'crook', 'shook', 'nook', 'rook', 'wood'],
      'star': ['car', 'bar', 'far', 'jar', 'tar', 'scar', 'guitar', 'cigar', 'radar', 'avatar'],
      'moon': ['soon', 'noon', 'spoon', 'tune', 'june', 'dune', 'prune', 'rune', 'balloon', 'cartoon'],
      'bird': ['word', 'heard', 'third', 'herd', 'nerd', 'curd', 'blurred', 'stirred', 'occurred', 'preferred'],
      'ship': ['trip', 'slip', 'clip', 'flip', 'grip', 'drip', 'skip', 'whip', 'chip', 'strip'],
      'ring': ['sing', 'king', 'wing', 'thing', 'bring', 'spring', 'swing', 'string', 'sting', 'cling'],
      'cloud': ['loud', 'proud', 'crowd', 'bowed', 'vowed', 'allowed', 'endowed', 'shroud', 'plowed', 'aloud']
    };
    
    // Check exact matches and also accept partial matches (more forgiving)
    const possibleRhymes = rhymes[word1.toLowerCase()] || [];
    const userWord = word2.toLowerCase();
    
    // Direct match
    if (possibleRhymes.includes(userWord)) return true;
    
    // Check for sound similarity (ends with same 2-3 letters)
    const word1End = word1.toLowerCase().slice(-2);
    const word2End = userWord.slice(-2);
    
    // More forgiving rhyme checking
    return word1End === word2End || 
           word1.toLowerCase().slice(-3) === userWord.slice(-3) ||
           possibleRhymes.some(rhyme => Math.abs(rhyme.length - userWord.length) <= 2 && 
                              rhyme.includes(userWord.slice(-2)));
  };

  const checkObjectName = (emoji: string, answer: string): boolean => {
    const objects: Record<string, string[]> = {
      '🐱': ['cat', 'kitten', 'kitty', 'feline', 'pet'],
      '🚗': ['car', 'auto', 'vehicle', 'automobile', 'sedan'],
      '⭐': ['star', 'asterisk', 'sparkle'],
      '🏠': ['house', 'home', 'building', 'residence'],
      '🌺': ['flower', 'bloom', 'blossom', 'petal', 'rose'],
      '🐶': ['dog', 'puppy', 'hound', 'canine', 'pet'],
      '🍎': ['apple', 'fruit', 'red apple'],
      '📱': ['phone', 'mobile', 'cell', 'smartphone', 'device'],
      '⚽': ['ball', 'soccer', 'football', 'sport'],
      '🎨': ['art', 'paint', 'palette', 'brush', 'painting'],
      '🌙': ['moon', 'crescent', 'lunar', 'night'],
      '🔥': ['fire', 'flame', 'heat', 'burn'],
      '🎸': ['guitar', 'music', 'instrument', 'string'],
      '🏀': ['basketball', 'ball', 'sport', 'orange'],
      '🌲': ['tree', 'pine', 'evergreen', 'forest', 'wood']
    };
    
    const userAnswer = answer.toLowerCase().trim();
    const possibleAnswers = objects[emoji] || [];
    
    // Check exact matches or partial matches
    return possibleAnswers.some(validAnswer => 
      validAnswer.includes(userAnswer) || 
      userAnswer.includes(validAnswer) ||
      validAnswer.toLowerCase() === userAnswer
    );
  };

  const endTest = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    const test = tests.find(t => t.id === currentTest);
    if (!test) return;

    const timeSpent = Math.floor((Date.now() - testState.startTime) / 1000);
    const totalQuestions = currentTest === 'phonological' || currentTest === 'rapid-naming' 
      ? testState.questions!.length 
      : test.questions!.length;
    const score = Math.round((testState.correctAnswers / totalQuestions) * 100);

    const newResult: TestResult = {
      type: currentTest!,
      score,
      timeSpent,
      completed: true
    };

    setResults(prev => {
      const filtered = prev.filter(r => r.type !== currentTest);
      return [...filtered, newResult];
    });

    // Save to database
    saveResultToDatabase(newResult);

    setCurrentTest(null);
    setTimeLeft(0);
    setTestState({
      isActive: false,
      currentQuestion: 0,
      userAnswers: [],
      correctAnswers: 0,
      startTime: 0,
      questions: []
    });

    toast({
      title: "Test Completed! 🎉",
      description: `You scored ${score}% (${testState.correctAnswers}/${totalQuestions} correct)`,
    });
  };

  const dyslexiaResult = getDyslexiaLevel();

  if (currentTest && testState.isActive) {
    const test = tests.find(t => t.id === currentTest);
    if (!test) return null;

    return (
      <div className="min-h-screen p-4 md:p-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center space-y-6">
            <div className={`w-20 h-20 ${test.color} rounded-2xl mx-auto flex items-center justify-center shadow-glow animate-pulse-soft`}>
              <test.icon className="w-10 h-10 text-white" />
            </div>
            
            <div className="space-y-2">
              <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                {test.title}
              </h1>
              <p className="text-muted-foreground text-dyslexic text-lg">
                Question {testState.currentQuestion + 1} of {
                  currentTest === 'phonological' || currentTest === 'rapid-naming' 
                    ? testState.questions?.length || 5
                    : test.questions!.length
                }
              </p>
            </div>

            <Card className="shadow-medium border-2 border-primary/10 max-w-2xl mx-auto">
              <CardContent className="p-8 space-y-6">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-display">Time Remaining</span>
                    <span className="text-2xl font-bold text-primary">
                      {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                    </span>
                  </div>
                  <Progress value={(timeLeft / test.time) * 100} className="h-4" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-display">Correct Answers</span>
                    <span className="text-xl font-bold text-success">
                      {testState.correctAnswers}/{testState.currentQuestion + 1}
                    </span>
                  </div>
                  <Progress 
                    value={testState.currentQuestion > 0 ? (testState.correctAnswers / (testState.currentQuestion + 1)) * 100 : 0} 
                    className="h-4 bg-success-soft" 
                  />
                </div>

                {currentTest === 'phonological' && (
                  <div className="space-y-4">
                    <div className="text-center p-6 bg-primary-soft rounded-xl">
                      <div className="text-3xl font-display font-bold text-primary mb-2">
                        {testState.questions![testState.currentQuestion] as string}
                      </div>
                      <div className="text-muted-foreground text-dyslexic">Type a word that rhymes with this!</div>
                    </div>
                    <Input 
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      placeholder="Enter your answer..."
                      className="text-center text-lg"
                      onKeyPress={(e) => e.key === 'Enter' && submitAnswer()}
                    />
                    <Button 
                      onClick={submitAnswer}
                      disabled={!userInput.trim()}
                      className="w-full"
                      size="lg"
                    >
                      Submit Answer
                    </Button>
                  </div>
                )}

                {currentTest === 'rapid-naming' && (
                  <div className="space-y-4">
                    <div className="text-center p-6 bg-secondary rounded-xl">
                      <div className="text-6xl mb-4">{testState.questions![testState.currentQuestion] as string}</div>
                      <div className="text-muted-foreground text-dyslexic">What is this object?</div>
                    </div>
                    <Input 
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      placeholder="Enter the object name..."
                      className="text-center text-lg"
                      onKeyPress={(e) => e.key === 'Enter' && submitAnswer()}
                    />
                    <Button 
                      onClick={submitAnswer}
                      disabled={!userInput.trim()}
                      className="w-full"
                      size="lg"
                    >
                      Submit Answer
                    </Button>
                  </div>
                )}

                {currentTest === 'working-memory' && (
                  <div className="space-y-4">
                    {showingSequence ? (
                      <div className="text-center p-6 bg-success-soft rounded-xl">
                        <div className="text-xl font-display text-success mb-4">Remember this sequence:</div>
                        <div className="text-3xl font-bold">
                          {currentSequence.join(' - ')}
                        </div>
                      </div>
                    ) : sequenceShown ? (
                      <>
                        <div className="text-center p-6 bg-success-soft rounded-xl">
                          <div className="text-xl font-display text-success mb-2">Type the sequence you saw:</div>
                          <div className="text-muted-foreground text-dyslexic">Enter numbers without spaces</div>
                        </div>
                        <Input 
                          value={userInput}
                          onChange={(e) => setUserInput(e.target.value)}
                          placeholder="Enter the sequence..."
                          className="text-center text-lg"
                          onKeyPress={(e) => e.key === 'Enter' && submitAnswer()}
                        />
                        <Button 
                          onClick={submitAnswer}
                          disabled={!userInput.trim()}
                          className="w-full"
                          size="lg"
                        >
                          Submit Answer
                        </Button>
                      </>
                    ) : (
                      <div className="text-center p-6 bg-muted rounded-xl">
                        <div className="text-lg text-muted-foreground">Get ready for the next sequence...</div>
                      </div>
                    )}
                  </div>
                )}

                {currentTest === 'reading-fluency' && (
                  <div className="space-y-4">
                    <div className="text-left p-6 bg-muted rounded-xl">
                      <div className="text-dyslexic text-lg leading-relaxed mb-4">
                        {(test.questions![testState.currentQuestion] as any).passage}
                      </div>
                      <div className="font-semibold text-primary">
                        Question: {(test.questions![testState.currentQuestion] as any).question}
                      </div>
                    </div>
                    <Input 
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      placeholder="Enter your answer..."
                      className="text-center text-lg"
                      onKeyPress={(e) => e.key === 'Enter' && submitAnswer()}
                    />
                    <Button 
                      onClick={submitAnswer}
                      disabled={!userInput.trim()}
                      className="w-full"
                      size="lg"
                    >
                      Submit Answer
                    </Button>
                  </div>
                )}

                <Button 
                  variant="ghost" 
                  onClick={() => {
                    if (timerRef.current) clearInterval(timerRef.current);
                    setCurrentTest(null);
                    setTestState({
                      isActive: false,
                      currentQuestion: 0,
                      userAnswers: [],
                      correctAnswers: 0,
                      startTime: 0,
                      questions: []
                    });
                  }}
                  className="w-full"
                >
                  Cancel Test
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="space-y-2">
            <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
              Dyslexia Assessment
            </h1>
            <p className="text-muted-foreground text-dyslexic">
              Complete all 4 tests to unlock your personalized learning experience
            </p>
          </div>
        </div>

        {/* Progress Overview */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-display">Assessment Progress</CardTitle>
              <span className="text-sm text-muted-foreground">
                {getCompletedCount()}/{tests.length} completed
              </span>
            </div>
          </CardHeader>
          <CardContent>
            <Progress value={getOverallProgress()} className="h-3" />
          </CardContent>
        </Card>

        {/* Results Display */}
        {dyslexiaResult && (
          <Card className="shadow-strong border-2 border-primary">
            <CardHeader>
              <CardTitle className="font-display text-center text-xl">
                Assessment Complete! 🎉
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className={`text-3xl font-display font-bold ${dyslexiaResult.color}`}>
                Dyslexia Likelihood: {dyslexiaResult.level}
              </div>
              <div className="text-muted-foreground text-dyslexic">
                Based on your test results, we've customized your learning experience
              </div>
              <Button 
                variant="success" 
                size="lg"
                onClick={() => navigate('/dashboard')}
                className="gap-2"
              >
                <CheckCircle className="w-5 h-5" />
                Start Personalized Learning
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Warning if trying to access dashboard without completing assessment */}
        {getCompletedCount() < tests.length && (
          <Card className="shadow-medium border-2 border-warning bg-warning-soft">
            <CardContent className="p-6 text-center">
              <div className="text-warning font-semibold mb-2">
                Complete Assessment Required
              </div>
              <div className="text-muted-foreground text-dyslexic">
                You must complete all 4 tests before accessing the learning dashboard
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tests Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {tests.map((test) => {
            const result = results.find(r => r.type === test.id);
            const isCompleted = result?.completed || false;

            return (
              <Card 
                key={test.id}
                className={`shadow-medium border-2 transition-all duration-300 hover:scale-105 ${
                  isCompleted 
                    ? 'border-success bg-success-soft' 
                    : 'border-primary/10 hover:shadow-strong'
                }`}
              >
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 ${test.color} rounded-2xl mx-auto flex items-center justify-center shadow-medium ${
                    isCompleted ? 'shadow-glow' : ''
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-8 h-8 text-white" />
                    ) : (
                      <test.icon className="w-8 h-8 text-white" />
                    )}
                  </div>
                  <CardTitle className="font-display text-lg">
                    {test.title}
                  </CardTitle>
                  <CardDescription className="text-dyslexic">
                    {test.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Time limit:</span>
                    <span className="font-semibold">{test.time} seconds</span>
                  </div>
                  
                  {result && (
                    <div className="space-y-2 p-3 bg-background rounded-lg">
                      <div className="flex justify-between text-sm">
                        <span>Score:</span>
                        <span className="font-bold text-success">{result.score}%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Time taken:</span>
                        <span>{result.timeSpent}s</span>
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    className="w-full"
                    variant={isCompleted ? "success" : "default"}
                    size="lg"
                    onClick={() => startTest(test.id)}
                    disabled={currentTest !== null}
                  >
                    {isCompleted ? "Retake Test" : "Start Test"}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Assessment;