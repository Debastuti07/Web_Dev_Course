import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { 
  BarChart3, 
  TrendingUp, 
  Calendar, 
  Clock, 
  Target,
  ArrowLeft,
  Award,
  BookOpen,
  Mic,
  Volume2
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const Progress = () => {
  const [assessmentData, setAssessmentData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchAssessmentData();
  }, []);

  const fetchAssessmentData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: results } = await supabase
        .from('assessment_results')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true });

      setAssessmentData(results || []);
    } catch (error) {
      console.error('Error fetching assessment data:', error);
      toast({
        title: "Error",
        description: "Failed to load progress data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const calculateDyslexiaLevel = (results: any[]) => {
    if (results.length === 0) return "Not assessed";
    
    const averageScore = results.reduce((acc, result) => acc + result.score, 0) / results.length;
    const averageTime = results.reduce((acc, result) => acc + result.time_spent, 0) / results.length;
    
    if (averageScore >= 80 && averageTime <= 30) return "Mild";
    if (averageScore >= 60 && averageTime <= 45) return "Moderate";
    return "Significant";
  };

  const getTestIcon = (testType: string) => {
    switch (testType) {
      case 'phonological': return BookOpen;
      case 'rapid-naming': return Clock;
      case 'working-memory': return Target;
      case 'reading-fluency': return Volume2;
      default: return BookOpen;
    }
  };

  const formatTestType = (testType: string) => {
    return testType.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-gradient-primary rounded-2xl mx-auto animate-pulse-soft flex items-center justify-center">
            <BarChart3 className="w-8 h-8 text-primary-foreground" />
          </div>
          <p className="text-muted-foreground text-dyslexic">Loading your progress...</p>
        </div>
      </div>
    );
  }

  const dyslexiaLevel = calculateDyslexiaLevel(assessmentData);
  const totalTests = assessmentData.length;
  const averageScore = totalTests > 0 ? Math.round(assessmentData.reduce((acc, result) => acc + result.score, 0) / totalTests) : 0;
  const averageTime = totalTests > 0 ? Math.round(assessmentData.reduce((acc, result) => acc + result.time_spent, 0) / totalTests) : 0;

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-gradient-primary rounded-2xl mx-auto flex items-center justify-center shadow-glow">
            <BarChart3 className="w-8 h-8 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">
              Reading Progress
            </h1>
            <p className="text-lg text-muted-foreground text-dyslexic">
              Track your learning journey and celebrate your improvements! 📈
            </p>
          </div>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/dashboard')}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>

        {/* Overall Progress Summary */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Overall Progress Summary
            </CardTitle>
            <CardDescription className="text-dyslexic">
              Your learning journey at a glance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-primary-soft rounded-xl">
                <div className="text-2xl font-display font-bold text-primary">{totalTests}</div>
                <div className="text-sm text-primary text-dyslexic">Tests Completed</div>
              </div>
              <div className="text-center p-4 bg-success-soft rounded-xl">
                <div className="text-2xl font-display font-bold text-success">{averageScore}%</div>
                <div className="text-sm text-success text-dyslexic">Average Score</div>
              </div>
              <div className="text-center p-4 bg-secondary rounded-xl">
                <div className="text-2xl font-display font-bold text-secondary-foreground">{averageTime}s</div>
                <div className="text-sm text-secondary-foreground text-dyslexic">Average Time</div>
              </div>
              <div className="text-center p-4 bg-gradient-warm rounded-xl">
                <Badge variant="secondary" className="text-white font-bold">
                  {dyslexiaLevel}
                </Badge>
                <div className="text-sm text-white text-dyslexic mt-1">Dyslexia Level</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Test Results */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Award className="w-5 h-5 text-primary" />
              Test Results Breakdown
            </CardTitle>
            <CardDescription className="text-dyslexic">
              Detailed performance in each assessment area
            </CardDescription>
          </CardHeader>
          <CardContent>
            {assessmentData.length > 0 ? (
              <div className="space-y-4">
                {assessmentData.map((result, index) => {
                  const TestIcon = getTestIcon(result.test_type);
                  const scoreColor = result.score >= 70 ? 'text-success' : result.score >= 40 ? 'text-warning' : 'text-destructive';
                  const bgColor = result.score >= 70 ? 'bg-success-soft' : result.score >= 40 ? 'bg-warning-soft' : 'bg-destructive-soft';
                  
                  return (
                    <div key={result.id} className={`p-4 ${bgColor} rounded-xl`}>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <TestIcon className={`w-6 h-6 ${scoreColor}`} />
                          <div>
                            <h3 className={`font-semibold ${scoreColor}`}>
                              {formatTestType(result.test_type)}
                            </h3>
                            <p className={`text-sm ${scoreColor} text-dyslexic`}>
                              Completed on {new Date(result.completed_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-2xl font-bold ${scoreColor}`}>
                            {result.score}%
                          </div>
                          <div className={`text-sm ${scoreColor} text-dyslexic`}>
                            {result.time_spent}s
                          </div>
                        </div>
                      </div>
                      <ProgressBar value={result.score} className="h-2" />
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground text-dyslexic">
                  No assessment data available yet. Complete your first assessment to see progress!
                </p>
                <Button 
                  onClick={() => navigate('/assessment')} 
                  className="mt-4"
                >
                  Take Assessment
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Reading Session Tracker */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Mic className="w-5 h-5 text-primary" />
              Live Reading Sessions
            </CardTitle>
            <CardDescription className="text-dyslexic">
              Track your live reading practice sessions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <Mic className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground text-dyslexic mb-4">
                Live reading analysis feature coming soon! This will help you track your reading fluency in real-time.
              </p>
              <Button variant="outline" disabled>
                Start Live Reading Session
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Goals and Achievements */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Target className="w-5 h-5 text-primary" />
              Learning Goals
            </CardTitle>
            <CardDescription className="text-dyslexic">
              Your personalized learning targets
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-primary-soft rounded-lg">
                <div>
                  <div className="font-semibold text-primary">Complete Daily Reading</div>
                  <div className="text-sm text-primary text-dyslexic">Read for 15 minutes each day</div>
                </div>
                <ProgressBar value={60} className="w-24 h-2" />
              </div>
              <div className="flex items-center justify-between p-3 bg-success-soft rounded-lg">
                <div>
                  <div className="font-semibold text-success">Improve Assessment Scores</div>
                  <div className="text-sm text-success text-dyslexic">Reach 80% average score</div>
                </div>
                <ProgressBar value={averageScore} className="w-24 h-2" />
              </div>
              <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                <div>
                  <div className="font-semibold text-secondary-foreground">Use Text-to-Speech</div>
                  <div className="text-sm text-secondary-foreground text-dyslexic">Practice 3 times per week</div>
                </div>
                <ProgressBar value={40} className="w-24 h-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Progress;