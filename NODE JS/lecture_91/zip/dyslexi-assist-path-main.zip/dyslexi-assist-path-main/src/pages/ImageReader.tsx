import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { 
  Camera, 
  Upload, 
  ImageIcon, 
  FileText, 
  Volume2,
  ArrowLeft,
  Loader2,
  CheckCircle,
  AlertCircle
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import Tesseract from 'tesseract.js';

const ImageReader = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [extractedText, setExtractedText] = useState("");
  const [isExtracting, setIsExtracting] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please select an image file (JPG, PNG, etc.)",
          variant: "destructive",
        });
        return;
      }

      setSelectedImage(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);

      // Reset extracted text
      setExtractedText("");
    }
  };

  const extractTextFromImage = async () => {
    if (!selectedImage) {
      toast({
        title: "No image selected",
        description: "Please select an image first",
        variant: "destructive",
      });
      return;
    }

    setIsExtracting(true);
    
    try {
      toast({
        title: "Processing image...",
        description: "Extracting text from your image, this may take a moment",
      });

      const result = await Tesseract.recognize(
        selectedImage,
        'eng',
        {
          logger: m => {
            if (m.status === 'recognizing text') {
              console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
            }
          }
        }
      );
      
      const extractedText = result.data.text.trim();
      
      if (extractedText) {
        setExtractedText(extractedText);
        toast({
          title: "Text extracted successfully!",
          description: "You can now listen to the extracted text",
        });
      } else {
        toast({
          title: "No text found",
          description: "No readable text was found in the image. Try a clearer image with visible text.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('OCR Error:', error);
      toast({
        title: "Extraction failed",
        description: "Failed to extract text from image. Please try again with a clearer image.",
        variant: "destructive",
      });
    } finally {
      setIsExtracting(false);
    }
  };

  const speakText = () => {
    if (!extractedText.trim()) {
      toast({
        title: "No text to speak",
        description: "Please extract text from an image first",
        variant: "destructive",
      });
      return;
    }

    if (isSpeaking) {
      speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(extractedText);
    utterance.rate = 0.8;
    utterance.pitch = 1;
    utterance.volume = 1;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => {
      setIsSpeaking(false);
      toast({
        title: "Speech failed",
        description: "Unable to play speech. Please try again.",
        variant: "destructive",
      });
    };

    speechSynthesis.speak(utterance);
  };

  const resetAll = () => {
    setSelectedImage(null);
    setImagePreview(null);
    setExtractedText("");
    speechSynthesis.cancel();
    setIsSpeaking(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-gradient-primary rounded-2xl mx-auto flex items-center justify-center shadow-glow">
            <Camera className="w-8 h-8 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">
              Image Text Reader
            </h1>
            <p className="text-lg text-muted-foreground text-dyslexic">
              Extract text from images and listen to it! 📷✨
            </p>
          </div>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/dashboard')}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>

        {/* Upload Section */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Upload className="w-5 h-5 text-primary" />
              Upload Image
            </CardTitle>
            <CardDescription className="text-dyslexic">
              Select an image with text that you'd like to read aloud
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
                size="lg"
                className="flex-1 h-16 gap-3"
              >
                <ImageIcon className="w-6 h-6" />
                Choose Image File
              </Button>
              <Button
                onClick={resetAll}
                variant="ghost"
                size="lg"
                className="flex-1 h-16 gap-3"
                disabled={!selectedImage}
              >
                Reset All
              </Button>
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />

            {/* Image Preview */}
            {imagePreview && (
              <div className="mt-6">
                <div className="border-2 border-dashed border-primary/20 rounded-xl p-4">
                  <img 
                    src={imagePreview} 
                    alt="Selected image" 
                    className="max-w-full max-h-64 mx-auto rounded-lg shadow-medium"
                  />
                  <div className="text-center mt-4">
                    <p className="text-sm text-muted-foreground text-dyslexic">
                      Selected: {selectedImage?.name}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Text Extraction */}
        {selectedImage && (
          <Card className="shadow-medium border-2 border-primary/10">
            <CardHeader>
              <CardTitle className="font-display flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Extract Text
              </CardTitle>
              <CardDescription className="text-dyslexic">
                Use OCR technology to extract text from your image
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                onClick={extractTextFromImage}
                disabled={isExtracting}
                size="lg"
                className="w-full gap-3"
              >
                {isExtracting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Extracting Text...
                  </>
                ) : (
                  <>
                    <FileText className="w-5 h-5" />
                    Extract Text from Image
                  </>
                )}
              </Button>

              {extractedText && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-success">
                    <CheckCircle className="w-5 h-5" />
                    <span className="font-semibold">Text extracted successfully!</span>
                  </div>
                  
                  <Textarea
                    value={extractedText}
                    onChange={(e) => setExtractedText(e.target.value)}
                    placeholder="Extracted text will appear here..."
                    className="min-h-32 text-dyslexic resize-none"
                  />
                  
                  <Button
                    onClick={speakText}
                    variant="secondary"
                    size="lg"
                    className="w-full gap-3"
                  >
                    <Volume2 className="w-5 h-5" />
                    {isSpeaking ? "Stop Speaking" : "Listen to Text"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Instructions */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-primary" />
              How to Use
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-dyslexic">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-bold flex-shrink-0 mt-0.5">
                  1
                </div>
                <p>Choose an image file that contains text you want to read</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-bold flex-shrink-0 mt-0.5">
                  2
                </div>
                <p>Click "Extract Text from Image" to use OCR technology</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-bold flex-shrink-0 mt-0.5">
                  3
                </div>
                <p>Edit the extracted text if needed, then click "Listen to Text"</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-bold flex-shrink-0 mt-0.5">
                  4
                </div>
                <p>Enjoy having the text read aloud to you!</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ImageReader;