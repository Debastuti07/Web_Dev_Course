import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { BookOpen, Brain, Heart, Sparkles, Users, Target, Award } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Brain,
      title: "Smart Assessment",
      description: "Advanced dyslexia detection with personalized results"
    },
    {
      icon: BookOpen,
      title: "Text-to-Speech",
      description: "Listen to any content with natural, clear voices"
    },
    {
      icon: Target,
      title: "Adaptive Learning",
      description: "Personalized activities based on your learning profile"
    },
    {
      icon: Award,
      title: "Progress Tracking",
      description: "Watch your reading skills improve over time"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="space-y-4">
            <div className="mx-auto w-20 h-20 bg-gradient-primary rounded-3xl flex items-center justify-center shadow-glow animate-float">
              <BookOpen className="w-10 h-10 text-primary-foreground" />
            </div>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-foreground">
              Welcome to{" "}
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                DyslexiAssist
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground text-dyslexic max-w-3xl mx-auto">
              Your personalized learning companion designed specifically for students with dyslexia. 
              Discover, learn, and grow with confidence! ✨
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              variant="default" 
              size="xl"
              onClick={() => navigate('/auth')}
              className="gap-3 shadow-glow"
            >
              <Heart className="w-6 h-6" />
              Start Your Journey
            </Button>
            <Button 
              variant="outline" 
              size="xl"
              onClick={() => navigate('/auth')}
              className="gap-3"
            >
              <Users className="w-6 h-6" />
              Join Our Community
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">
              Everything You Need to Succeed
            </h2>
            <p className="text-lg text-muted-foreground text-dyslexic max-w-2xl mx-auto">
              Our platform combines cutting-edge technology with compassionate design 
              to create the perfect learning environment for dyslexic students.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card 
                key={feature.title}
                className="shadow-medium border-2 border-primary/10 hover:shadow-strong transition-all duration-300 hover:scale-105 group"
              >
                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 bg-gradient-primary rounded-2xl mx-auto flex items-center justify-center shadow-medium group-hover:shadow-glow transition-all duration-300 animate-float`}
                       style={{ animationDelay: `${index * 0.2}s` }}>
                    <feature.icon className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="font-display text-lg">
                    {feature.title}
                  </CardTitle>
                  <CardDescription className="text-dyslexic">
                    {feature.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-primary text-primary-foreground shadow-glow border-0">
            <CardContent className="text-center p-12">
              <div className="space-y-6">
                <div className="flex items-center justify-center gap-3 mb-6">
                  <Sparkles className="w-8 h-8" />
                  <h3 className="text-2xl md:text-3xl font-display font-bold">
                    Ready to Transform Your Learning?
                  </h3>
                  <Sparkles className="w-8 h-8" />
                </div>
                <p className="text-lg text-dyslexic opacity-90 max-w-2xl mx-auto">
                  Join thousands of students who have discovered the joy of learning with DyslexiAssist. 
                  Your journey to confident reading starts here!
                </p>
                <Button 
                  variant="secondary" 
                  size="xl"
                  onClick={() => navigate('/auth')}
                  className="gap-3 shadow-strong hover:scale-110"
                >
                  <BookOpen className="w-6 h-6" />
                  Get Started for Free
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 text-center text-muted-foreground">
        <div className="max-w-4xl mx-auto space-y-4">
          <div className="flex items-center justify-center gap-2">
            <Heart className="w-5 h-5 text-primary" />
            <p className="text-dyslexic">
              Built with love for students who learn differently
            </p>
            <Heart className="w-5 h-5 text-primary" />
          </div>
          <p className="text-sm">
            Empowering every student to reach their full potential through inclusive, accessible education.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
