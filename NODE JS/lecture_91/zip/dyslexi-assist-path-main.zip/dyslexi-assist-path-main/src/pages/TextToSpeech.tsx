import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { ArrowLeft, Volume2, VolumeX, Play, Pause, RotateCcw, BookOpen, Zap, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useElevenLabsTTS, ELEVENLABS_VOICES } from "@/hooks/useElevenLabsTTS";

const TextToSpeech = () => {
  const [text, setText] = useState(`Welcome to DyslexiAssist! This is your personal text-to-speech reader with AI-powered voices! 

You can paste any text here, and I'll read it aloud using premium ElevenLabs AI voices that sound incredibly natural and expressive. This tool is specially designed to help students with dyslexia enjoy reading and learning.

Try our high-quality AI voices below - they're much more natural than standard browser voices! You can choose from different voice personalities and adjust settings to make your listening experience perfect!`);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedVoice, setSelectedVoice] = useState("9BWtsMINqrJLrRacOk9x"); // Aria default
  const [useElevenLabs, setUseElevenLabs] = useState(true);
  const [rate, setRate] = useState([1]);
  const [volume, setVolume] = useState([0.8]);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // ElevenLabs TTS hook
  const { 
    isLoading: isElevenLabsLoading, 
    isPlaying: isElevenLabsPlaying, 
    speakWithElevenLabs, 
    stopAudio: stopElevenLabsAudio 
  } = useElevenLabsTTS();

  // Load available voices
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = speechSynthesis.getVoices();
      setVoices(availableVoices);
    };

    loadVoices();
    speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  const speakText = async () => {
    if (!text.trim()) {
      toast({
        title: "No text to read",
        description: "Please enter some text first!",
        variant: "destructive",
      });
      return;
    }

    if (useElevenLabs) {
      // Use ElevenLabs AI voice
      await speakWithElevenLabs(text, selectedVoice);
    } else {
      // Use browser speech synthesis
      speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utteranceRef.current = utterance;

      if (selectedVoice !== "default") {
        const voice = voices.find(v => v.name === selectedVoice);
        if (voice) {
          utterance.voice = voice;
        }
      }

      utterance.rate = rate[0];
      utterance.volume = volume[0];
      utterance.pitch = 1;

      utterance.onstart = () => {
        setIsPlaying(true);
        toast({
          title: "Reading started! 📖",
          description: "Listening to your text...",
        });
      };

      utterance.onend = () => {
        setIsPlaying(false);
        toast({
          title: "Reading finished! ✨",
          description: "Hope you enjoyed listening!",
        });
      };

      utterance.onerror = () => {
        setIsPlaying(false);
        toast({
          title: "Speech error",
          description: "Something went wrong with the speech synthesis",
          variant: "destructive",
        });
      };

      speechSynthesis.speak(utterance);
    }
  };

  const pauseReading = () => {
    if (useElevenLabs) {
      stopElevenLabsAudio();
    } else if (speechSynthesis.speaking) {
      speechSynthesis.pause();
      setIsPlaying(false);
      toast({
        title: "Reading paused",
        description: "Click play to continue",
      });
    }
  };

  const resumeReading = () => {
    if (useElevenLabs) {
      speakText();
    } else if (speechSynthesis.paused) {
      speechSynthesis.resume();
      setIsPlaying(true);
    } else {
      speakText();
    }
  };

  const stopReading = () => {
    if (useElevenLabs) {
      stopElevenLabsAudio();
    } else {
      speechSynthesis.cancel();
      setIsPlaying(false);
    }
    
    toast({
      title: "Reading stopped",
      description: "Ready for new text!",
    });
  };

  const currentlyPlaying = useElevenLabs ? isElevenLabsPlaying : isPlaying;
  const currentlyLoading = useElevenLabs ? isElevenLabsLoading : false;

  const sampleTexts = [
    {
      title: "Science Fun",
      content: "Did you know that butterflies taste with their feet? They land on flowers and can immediately tell if the flower has the sweet nectar they love to drink!"
    },
    {
      title: "Space Adventure",
      content: "The International Space Station travels around Earth at an amazing speed of 17,500 miles per hour. That means it goes around our entire planet every 90 minutes!"
    },
    {
      title: "Ocean Wonders",
      content: "The blue whale is the largest animal that has ever lived on Earth - even bigger than dinosaurs! Their hearts alone can weigh as much as a small car."
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="space-y-2">
            <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
              Text-to-Speech Reader
            </h1>
            <p className="text-muted-foreground text-dyslexic">
              Listen to any text with AI-powered voices 🎵✨
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Text Area */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="shadow-medium border-2 border-primary/10">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
                    <BookOpen className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="font-display">Enter Your Text</CardTitle>
                    <CardDescription className="text-dyslexic">
                      Paste or type any text you'd like to hear
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Type or paste your text here..."
                  className="min-h-[300px] text-dyslexic text-lg leading-relaxed resize-none"
                />
                
                <div className="flex flex-wrap gap-3">
                  <Button 
                    variant={currentlyPlaying ? "destructive" : "default"}
                    size="lg"
                    onClick={currentlyPlaying ? pauseReading : resumeReading}
                    disabled={currentlyLoading}
                    className="gap-2"
                  >
                    {currentlyLoading ? (
                      <>
                        <Sparkles className="w-5 h-5 animate-spin" />
                        {useElevenLabs ? "Generating AI Voice..." : "Loading..."}
                      </>
                    ) : currentlyPlaying ? (
                      <>
                        <Pause className="w-5 h-5" />
                        Pause
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5" />
                        {useElevenLabs ? "Play with AI Voice" : "Play"}
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    variant="outline"
                    size="lg"
                    onClick={stopReading}
                    disabled={!currentlyPlaying && !currentlyLoading}
                    className="gap-2"
                  >
                    <RotateCcw className="w-5 h-5" />
                    Stop
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Sample Texts */}
            <Card className="shadow-medium border-2 border-primary/10">
              <CardHeader>
                <CardTitle className="font-display">Try These Sample Texts</CardTitle>
                <CardDescription className="text-dyslexic">
                  Click any card to load it into the reader
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {sampleTexts.map((sample, index) => (
                    <div
                      key={index}
                      className="p-4 rounded-xl bg-primary-soft hover:bg-primary/20 cursor-pointer transition-all duration-200 hover:scale-105"
                      onClick={() => setText(sample.content)}
                    >
                      <h4 className="font-display font-semibold text-primary mb-2">
                        {sample.title}
                      </h4>
                      <p className="text-sm text-dyslexic text-muted-foreground">
                        {sample.content.substring(0, 80)}...
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Settings Panel */}
          <div className="space-y-6">
            <Card className="shadow-medium border-2 border-primary/10">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-warm rounded-lg flex items-center justify-center">
                    <Volume2 className="w-5 h-5 text-secondary-foreground" />
                  </div>
                  <CardTitle className="font-display">Voice Settings</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Voice Engine Toggle */}
                <div className="space-y-3">
                  <label className="text-sm font-display font-semibold">Voice Engine</label>
                  <div className="flex gap-2">
                    <Button
                      variant={useElevenLabs ? "default" : "outline"}
                      size="sm"
                      onClick={() => setUseElevenLabs(true)}
                      className="gap-2 flex-1"
                    >
                      <Zap className="w-4 h-4" />
                      AI Voices
                      <Badge variant="secondary" className="ml-1">Premium</Badge>
                    </Button>
                    <Button
                      variant={!useElevenLabs ? "default" : "outline"}
                      size="sm"
                      onClick={() => setUseElevenLabs(false)}
                      className="gap-2 flex-1"
                    >
                      <Volume2 className="w-4 h-4" />
                      Browser Voices
                    </Button>
                  </div>
                </div>

                {/* Voice Selection */}
                <div className="space-y-2">
                  <label className="text-sm font-display font-semibold">
                    {useElevenLabs ? "AI Voice" : "Browser Voice"}
                  </label>
                  <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a voice" />
                    </SelectTrigger>
                    <SelectContent>
                      {useElevenLabs ? (
                        ELEVENLABS_VOICES.map((voice) => (
                          <SelectItem key={voice.voice_id} value={voice.voice_id}>
                            <div className="flex items-center gap-2">
                              <span>{voice.name}</span>
                              <Badge variant="outline" className="text-xs">
                                {voice.category}
                              </Badge>
                            </div>
                          </SelectItem>
                        ))
                      ) : (
                        <>
                          <SelectItem value="default">Default Voice</SelectItem>
                          {voices
                            .filter(voice => voice.lang.startsWith('en'))
                            .map((voice) => (
                              <SelectItem key={voice.name} value={voice.name}>
                                {voice.name}
                              </SelectItem>
                            ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                  
                  {useElevenLabs && (
                    <p className="text-xs text-muted-foreground">
                      {ELEVENLABS_VOICES.find(v => v.voice_id === selectedVoice)?.description}
                    </p>
                  )}
                </div>

                {/* Speed Control - Only for browser voices */}
                {!useElevenLabs && (
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <label className="text-sm font-display font-semibold">Speed</label>
                      <span className="text-sm text-muted-foreground">{rate[0]}x</span>
                    </div>
                    <Slider
                      value={rate}
                      onValueChange={setRate}
                      min={0.5}
                      max={2}
                      step={0.1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Slow</span>
                      <span>Fast</span>
                    </div>
                  </div>
                )}

                {/* Volume Control - Only for browser voices */}
                {!useElevenLabs && (
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <label className="text-sm font-display font-semibold">Volume</label>
                      <span className="text-sm text-muted-foreground">{Math.round(volume[0] * 100)}%</span>
                    </div>
                    <Slider
                      value={volume}
                      onValueChange={setVolume}
                      min={0}
                      max={1}
                      step={0.1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <VolumeX className="w-4 h-4" />
                      <Volume2 className="w-4 h-4" />
                    </div>
                  </div>
                )}

                {/* ElevenLabs Info */}
                {useElevenLabs && (
                  <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-4 h-4 text-primary" />
                      <span className="text-sm font-semibold text-primary">AI Voice Features</span>
                    </div>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      <li>• Premium natural-sounding voices</li>
                      <li>• Advanced emotion and expression</li>
                      <li>• Consistent pronunciation</li>
                      <li>• Perfect for learning and accessibility</li>
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card className="shadow-medium border-2 border-success/20 bg-success-soft">
              <CardHeader>
                <CardTitle className="font-display text-success">💡 Quick Tips</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-dyslexic space-y-2">
                <p>• AI voices sound incredibly natural</p>
                <p>• Try different voice personalities</p>
                <p>• You can pause and resume anytime</p>
                <p>• Perfect for studying and homework!</p>
                <p>• Switch to browser voices if needed</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TextToSpeech;