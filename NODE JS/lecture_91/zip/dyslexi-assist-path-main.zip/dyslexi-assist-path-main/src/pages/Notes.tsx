import { useState, useEffect } from "react";
import { PenTool, AlertTriangle, Plus, Save, Trash2, ArrowLeft, Search, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Note {
  id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
}

interface UserMistake {
  id: string;
  mistake_text: string;
  correction: string;
  mistake_type: string;
  context: string;
  created_at: string;
}

const Notes = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [mistakes, setMistakes] = useState<UserMistake[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [newNote, setNewNote] = useState({ title: "", content: "" });
  const [editingNote, setEditingNote] = useState<string | null>(null);
  const [newMistake, setNewMistake] = useState({
    mistake_text: "",
    correction: "",
    mistake_type: "spelling",
    context: ""
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [notesResponse, mistakesResponse] = await Promise.all([
        supabase
          .from('notes')
          .select('*')
          .eq('user_id', user.id)
          .order('updated_at', { ascending: false }),
        supabase
          .from('user_mistakes')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
      ]);

      if (notesResponse.error) {
        toast({
          title: "Error",
          description: "Failed to load notes",
          variant: "destructive",
        });
      } else {
        setNotes(notesResponse.data || []);
      }

      if (mistakesResponse.error) {
        toast({
          title: "Error", 
          description: "Failed to load mistakes",
          variant: "destructive",
        });
      } else {
        setMistakes(mistakesResponse.data || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveNote = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      if (!newNote.title.trim() || !newNote.content.trim()) {
        toast({
          title: "Error",
          description: "Please fill in both title and content",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('notes')
        .insert({
          user_id: user.id,
          title: newNote.title.trim(),
          content: newNote.content.trim()
        });

      if (error) {
        toast({
          title: "Error",
          description: "Failed to save note",
          variant: "destructive",
        });
        return;
      }

      setNewNote({ title: "", content: "" });
      fetchData();
      toast({
        title: "Success",
        description: "Note saved successfully",
      });
    } catch (error) {
      console.error('Error saving note:', error);
    }
  };

  const deleteNote = async (noteId: string) => {
    try {
      const { error } = await supabase
        .from('notes')
        .delete()
        .eq('id', noteId);

      if (error) {
        toast({
          title: "Error",
          description: "Failed to delete note",
          variant: "destructive",
        });
        return;
      }

      fetchData();
      toast({
        title: "Success",
        description: "Note deleted successfully",
      });
    } catch (error) {
      console.error('Error deleting note:', error);
    }
  };

  const saveMistake = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      if (!newMistake.mistake_text.trim() || !newMistake.correction.trim()) {
        toast({
          title: "Error",
          description: "Please fill in mistake text and correction",
          variant: "destructive",
        });
        return;
      }

      const { error } = await supabase
        .from('user_mistakes')
        .insert({
          user_id: user.id,
          mistake_text: newMistake.mistake_text.trim(),
          correction: newMistake.correction.trim(),
          mistake_type: newMistake.mistake_type,
          context: newMistake.context.trim()
        });

      if (error) {
        toast({
          title: "Error",
          description: "Failed to save mistake",
          variant: "destructive",
        });
        return;
      }

      setNewMistake({
        mistake_text: "",
        correction: "",
        mistake_type: "spelling",
        context: ""
      });
      fetchData();
      toast({
        title: "Success",
        description: "Mistake recorded successfully",
      });
    } catch (error) {
      console.error('Error saving mistake:', error);
    }
  };

  const getMistakeTypeColor = (type: string) => {
    switch (type) {
      case 'spelling': return 'bg-red-100 text-red-800';
      case 'grammar': return 'bg-blue-100 text-blue-800';
      case 'reading': return 'bg-yellow-100 text-yellow-800';
      case 'writing': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredNotes = notes.filter(note =>
    note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    note.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredMistakes = mistakes.filter(mistake =>
    mistake.mistake_text.toLowerCase().includes(searchTerm.toLowerCase()) ||
    mistake.correction.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow animate-pulse">
            <PenTool className="w-6 h-6 text-primary-foreground" />
          </div>
          <p className="text-muted-foreground">Loading your notes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
            className="rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow">
              <PenTool className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                Notes & Mistakes
              </h1>
              <p className="text-muted-foreground text-dyslexic">
                Keep track of your learning and improvement
              </p>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search notes and mistakes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <Tabs defaultValue="notes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="notes" className="gap-2">
              <PenTool className="w-4 h-4" />
              Notes
            </TabsTrigger>
            <TabsTrigger value="mistakes" className="gap-2">
              <AlertTriangle className="w-4 h-4" />
              Mistakes
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notes" className="space-y-6">
            {/* Add New Note */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Add New Note
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Note title..."
                  value={newNote.title}
                  onChange={(e) => setNewNote(prev => ({ ...prev, title: e.target.value }))}
                />
                <Textarea
                  placeholder="Write your note here..."
                  value={newNote.content}
                  onChange={(e) => setNewNote(prev => ({ ...prev, content: e.target.value }))}
                  rows={4}
                />
                <Button onClick={saveNote} className="gap-2">
                  <Save className="w-4 h-4" />
                  Save Note
                </Button>
              </CardContent>
            </Card>

            {/* Notes List */}
            <div className="grid gap-4">
              {filteredNotes.map((note) => (
                <Card key={note.id}>
                  <CardHeader className="flex flex-row items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg text-dyslexic">{note.title}</CardTitle>
                      <CardDescription className="flex items-center gap-2">
                        <Calendar className="w-3 h-3" />
                        {new Date(note.updated_at).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteNote(note.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <p className="text-dyslexic whitespace-pre-wrap">{note.content}</p>
                  </CardContent>
                </Card>
              ))}
              
              {filteredNotes.length === 0 && (
                <div className="text-center py-12 space-y-4">
                  <PenTool className="w-12 h-12 text-muted-foreground mx-auto" />
                  <div>
                    <h3 className="text-lg font-medium">No notes yet</h3>
                    <p className="text-muted-foreground">
                      Start by creating your first note above
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="mistakes" className="space-y-6">
            {/* Add New Mistake */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Record a Mistake
                </CardTitle>
                <CardDescription>
                  Keep track of mistakes to learn from them
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    placeholder="What was the mistake?"
                    value={newMistake.mistake_text}
                    onChange={(e) => setNewMistake(prev => ({ ...prev, mistake_text: e.target.value }))}
                  />
                  <Input
                    placeholder="What's the correction?"
                    value={newMistake.correction}
                    onChange={(e) => setNewMistake(prev => ({ ...prev, correction: e.target.value }))}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <select
                    className="w-full px-3 py-2 border border-input bg-background rounded-md text-sm"
                    value={newMistake.mistake_type}
                    onChange={(e) => setNewMistake(prev => ({ ...prev, mistake_type: e.target.value }))}
                  >
                    <option value="spelling">Spelling</option>
                    <option value="grammar">Grammar</option>
                    <option value="reading">Reading</option>
                    <option value="writing">Writing</option>
                  </select>
                  <Input
                    placeholder="Context (optional)"
                    value={newMistake.context}
                    onChange={(e) => setNewMistake(prev => ({ ...prev, context: e.target.value }))}
                  />
                </div>
                <Button onClick={saveMistake} className="gap-2">
                  <Save className="w-4 h-4" />
                  Record Mistake
                </Button>
              </CardContent>
            </Card>

            {/* Mistakes List */}
            <div className="grid gap-4">
              {filteredMistakes.map((mistake) => (
                <Card key={mistake.id}>
                  <CardContent className="pt-6">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <Badge className={getMistakeTypeColor(mistake.mistake_type)}>
                          {mistake.mistake_type}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {new Date(mistake.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-destructive mb-1">Mistake:</p>
                          <p className="text-dyslexic bg-destructive/10 p-2 rounded">
                            {mistake.mistake_text}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-green-600 mb-1">Correction:</p>
                          <p className="text-dyslexic bg-green-50 p-2 rounded">
                            {mistake.correction}
                          </p>
                        </div>
                      </div>
                      
                      {mistake.context && (
                        <div>
                          <p className="text-sm font-medium mb-1">Context:</p>
                          <p className="text-dyslexic text-muted-foreground">{mistake.context}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {filteredMistakes.length === 0 && (
                <div className="text-center py-12 space-y-4">
                  <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto" />
                  <div>
                    <h3 className="text-lg font-medium">No mistakes recorded</h3>
                    <p className="text-muted-foreground">
                      Recording mistakes helps track your improvement
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Notes;