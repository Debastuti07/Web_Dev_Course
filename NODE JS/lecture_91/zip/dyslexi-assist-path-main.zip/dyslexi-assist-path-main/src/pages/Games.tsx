import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { 
  Gamepad2, 
  Trophy, 
  Star, 
  Play, 
  Pause, 
  RotateCcw,
  CheckCircle,
  ArrowLeft,
  Volume2
} from "lucide-react";
import { useNavigate } from "react-router-dom";

const Games = () => {
  const [currentGame, setCurrentGame] = useState<string | null>(null);
  const [gameState, setGameState] = useState<any>({});
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [userInput, setUserInput] = useState("");
  const [timeLeft, setTimeLeft] = useState(0);
  const [isGameActive, setIsGameActive] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const games = [
    {
      id: "word-match",
      title: "Word Matching",
      description: "Match words with their pictures to improve vocabulary",
      difficulty: "Easy",
      icon: "🎯",
      color: "bg-gradient-primary"
    },
    {
      id: "sound-game",
      title: "Sound Recognition",
      description: "Listen to sounds and identify the correct word",
      difficulty: "Medium",
      icon: "🔊",
      color: "bg-gradient-warm"
    },
    {
      id: "letter-sequence",
      title: "Letter Sequencing",
      description: "Arrange letters in the correct order to form words",
      difficulty: "Medium",
      icon: "🔤",
      color: "bg-gradient-success"
    },
    {
      id: "memory-cards",
      title: "Memory Cards",
      description: "Flip cards to match pairs and improve memory",
      difficulty: "Hard",
      icon: "🧠",
      color: "bg-secondary-warm"
    }
  ];

  // Game data
  const gameData = {
    "word-match": {
      words: [
        { word: "CAT", emoji: "🐱", options: ["DOG", "CAT", "BIRD"] },
        { word: "SUN", emoji: "☀️", options: ["MOON", "SUN", "STAR"] },
        { word: "TREE", emoji: "🌲", options: ["TREE", "FLOWER", "GRASS"] },
        { word: "CAR", emoji: "🚗", options: ["BIKE", "TRAIN", "CAR"] },
        { word: "HOUSE", emoji: "🏠", options: ["HOUSE", "SHOP", "SCHOOL"] }
      ]
    },
    "letter-sequence": {
      words: [
        { scrambled: "TAC", correct: "CAT" },
        { scrambled: "GOD", correct: "DOG" },
        { scrambled: "UNS", correct: "SUN" },
        { scrambled: "RETE", correct: "TREE" },
        { scrambled: "KBOO", correct: "BOOK" }
      ]
    },
    "memory-cards": {
      pairs: [
        { id: 1, content: "🐱", match: "CAT" },
        { id: 2, content: "🚗", match: "CAR" },
        { id: 3, content: "⭐", match: "STAR" },
        { id: 4, content: "🏠", match: "HOME" },
        { id: 5, content: "🌺", match: "FLOWER" }
      ]
    }
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isGameActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            endGame();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isGameActive, timeLeft]);

  const startGame = (gameId: string) => {
    setCurrentGame(gameId);
    setScore(0);
    setLevel(1);
    setUserInput("");
    setTimeLeft(60); // 1 minute for each game
    setIsGameActive(true);
    
    // Initialize game state
    const newGameState: any = { currentQuestion: 0, questions: [] };
    
    if (gameId === "word-match") {
      newGameState.questions = gameData["word-match"].words.sort(() => Math.random() - 0.5);
    } else if (gameId === "letter-sequence") {
      newGameState.questions = gameData["letter-sequence"].words.sort(() => Math.random() - 0.5);
    } else if (gameId === "memory-cards") {
      newGameState.questions = gameData["memory-cards"].pairs.sort(() => Math.random() - 0.5);
      newGameState.flippedCards = [];
      newGameState.matchedPairs = [];
    } else if (gameId === "sound-game") {
      // For sound game, use word-match data
      newGameState.questions = gameData["word-match"].words.sort(() => Math.random() - 0.5);
    }
    
    setGameState(newGameState);
    
    toast({
      title: "Game Started!",
      description: "Good luck! Remember, learning is fun! 🎮",
    });
  };

  const submitAnswer = () => {
    if (!currentGame || !userInput.trim()) return;

    const game = games.find(g => g.id === currentGame);
    if (!game) return;

    let isCorrect = false;
    const currentQuestion = gameState.questions[gameState.currentQuestion];

    switch (currentGame) {
      case "word-match":
        isCorrect = userInput.toUpperCase() === currentQuestion.word;
        break;
      case "letter-sequence":
        isCorrect = userInput.toUpperCase() === currentQuestion.correct;
        break;
      case "sound-game":
        // Simple sound game - user types what they think the word is
        isCorrect = userInput.length >= 3; // Accept any reasonable attempt
        break;
      case "memory-cards":
        isCorrect = userInput.toUpperCase() === currentQuestion.match;
        break;
    }

    if (isCorrect) {
      setScore(prev => prev + 10);
      toast({
        title: "Correct! 🎉",
        description: "+10 points",
      });
    } else {
      toast({
        title: "Try again! 💪",
        description: "Keep going, you're doing great!",
        variant: "destructive"
      });
    }

    // Move to next question
    const nextQuestion = gameState.currentQuestion + 1;
    if (nextQuestion >= gameState.questions.length) {
      endGame();
    } else {
      setGameState(prev => ({ ...prev, currentQuestion: nextQuestion }));
      setUserInput("");
    }
  };

  const endGame = () => {
    setIsGameActive(false);
    setCurrentGame(null);
    toast({
      title: "Great job!",
      description: `You scored ${score} points! Keep practicing! ⭐`,
    });
  };

  const playSound = (word: string) => {
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.rate = 0.8;
    utterance.pitch = 1;
    speechSynthesis.speak(utterance);
  };

  if (currentGame && isGameActive) {
    const game = games.find(g => g.id === currentGame);
    const currentQuestion = gameState.questions?.[gameState.currentQuestion];
    
    if (!game || !currentQuestion) return null;

    return (
      <div className="min-h-screen p-4 md:p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Game Header */}
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={() => {
                setIsGameActive(false);
                setCurrentGame(null);
              }}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Games
            </Button>
            <div className="flex items-center gap-4">
              <Badge variant="secondary">Level {level}</Badge>
              <Badge variant="outline">Score: {score}</Badge>
              <Badge variant="outline">
                Time: {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
              </Badge>
            </div>
          </div>

          {/* Game Area */}
          <Card className="shadow-medium border-2 border-primary/10">
            <CardHeader>
              <CardTitle className="font-display text-center">
                {game.title}
              </CardTitle>
              <CardDescription className="text-center">
                Question {gameState.currentQuestion + 1} of {gameState.questions.length}
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <Progress 
                value={((gameState.currentQuestion + 1) / gameState.questions.length) * 100} 
                className="h-3" 
              />

              {/* Word Match Game */}
              {currentGame === "word-match" && (
                <div className="space-y-4">
                  <div className="text-8xl mb-4">{currentQuestion.emoji}</div>
                  <p className="text-lg text-muted-foreground text-dyslexic">
                    What word matches this picture?
                  </p>
                  <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                    {currentQuestion.options.map((option: string) => (
                      <Button
                        key={option}
                        variant="outline"
                        onClick={() => {
                          setUserInput(option);
                          setTimeout(submitAnswer, 100);
                        }}
                        className="h-12 text-lg"
                      >
                        {option}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Letter Sequence Game */}
              {currentGame === "letter-sequence" && (
                <div className="space-y-4">
                  <div className="text-3xl font-bold text-primary mb-4">
                    {currentQuestion.scrambled}
                  </div>
                  <p className="text-lg text-muted-foreground text-dyslexic">
                    Unscramble these letters to make a word!
                  </p>
                  <Input
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder="Type the correct word..."
                    className="text-center text-lg max-w-md mx-auto"
                    onKeyPress={(e) => e.key === 'Enter' && submitAnswer()}
                  />
                  <Button onClick={submitAnswer} disabled={!userInput.trim()}>
                    Submit Answer
                  </Button>
                </div>
              )}

              {/* Sound Game */}
              {currentGame === "sound-game" && (
                <div className="space-y-4">
                  <div className="text-6xl mb-4">🔊</div>
                  <p className="text-lg text-muted-foreground text-dyslexic">
                    Listen to the word and type what you hear!
                  </p>
                  <Button
                    onClick={() => playSound(gameState.questions[gameState.currentQuestion % 5]?.word || "HELLO")}
                    variant="outline"
                    className="gap-2"
                  >
                    <Volume2 className="w-4 h-4" />
                    Play Sound
                  </Button>
                  <Input
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder="Type what you heard..."
                    className="text-center text-lg max-w-md mx-auto"
                    onKeyPress={(e) => e.key === 'Enter' && submitAnswer()}
                  />
                  <Button onClick={submitAnswer} disabled={!userInput.trim()}>
                    Submit Answer
                  </Button>
                </div>
              )}

              {/* Memory Cards Game */}
              {currentGame === "memory-cards" && (
                <div className="space-y-4">
                  <div className="text-6xl mb-4">{currentQuestion.content}</div>
                  <p className="text-lg text-muted-foreground text-dyslexic">
                    What word matches this symbol?
                  </p>
                  <Input
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder="Type the matching word..."
                    className="text-center text-lg max-w-md mx-auto"
                    onKeyPress={(e) => e.key === 'Enter' && submitAnswer()}
                  />
                  <Button onClick={submitAnswer} disabled={!userInput.trim()}>
                    Submit Answer
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-gradient-primary rounded-2xl mx-auto flex items-center justify-center shadow-glow">
            <Gamepad2 className="w-8 h-8 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground">
              Learning Games
            </h1>
            <p className="text-lg text-muted-foreground text-dyslexic">
              Fun and engaging games designed to help you learn! 🎮
            </p>
          </div>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/dashboard')}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>

        {/* Stats Overview */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Trophy className="w-5 h-5 text-primary" />
              Your Gaming Stats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-primary-soft rounded-xl">
                <div className="text-2xl font-display font-bold text-primary">8</div>
                <div className="text-sm text-primary text-dyslexic">Games Played</div>
              </div>
              <div className="text-center p-4 bg-success-soft rounded-xl">
                <div className="text-2xl font-display font-bold text-success">{score}</div>
                <div className="text-sm text-success text-dyslexic">Current Score</div>
              </div>
              <div className="text-center p-4 bg-secondary rounded-xl">
                <div className="text-2xl font-display font-bold text-secondary-foreground">3</div>
                <div className="text-sm text-secondary-foreground text-dyslexic">Achievements</div>
              </div>
              <div className="text-center p-4 bg-gradient-warm rounded-xl">
                <div className="text-2xl font-display font-bold text-white">Level {level}</div>
                <div className="text-sm text-white text-dyslexic">Current Level</div>
              </div>
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-dyslexic">Progress to Next Level</span>
                <span className="font-semibold">75/100 XP</span>
              </div>
              <Progress value={75} className="h-3" />
            </div>
          </CardContent>
        </Card>

        {/* Games Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {games.map((game, index) => (
            <Card 
              key={game.id}
              className="shadow-medium border-2 border-primary/10 hover:shadow-strong transition-all duration-300 hover:scale-105 group"
            >
              <CardHeader className="text-center">
                <div className={`w-16 h-16 ${game.color} rounded-2xl mx-auto flex items-center justify-center shadow-medium group-hover:shadow-glow transition-all duration-300`}>
                  <span className="text-3xl">{game.icon}</span>
                </div>
                <CardTitle className="font-display">{game.title}</CardTitle>
                <CardDescription className="text-dyslexic">
                  {game.description}
                </CardDescription>
                <Badge variant="outline" className="mx-auto w-fit">
                  {game.difficulty}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  className="w-full group-hover:scale-105 transition-transform duration-200"
                  onClick={() => startGame(game.id)}
                  size="lg"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Start Game
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Achievements Section */}
        <Card className="shadow-medium border-2 border-primary/10">
          <CardHeader>
            <CardTitle className="font-display flex items-center gap-2">
              <Star className="w-5 h-5 text-primary" />
              Recent Achievements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-success-soft rounded-lg">
                <CheckCircle className="w-5 h-5 text-success" />
                <div>
                  <div className="font-semibold text-success">Word Master!</div>
                  <div className="text-sm text-success text-dyslexic">Completed 10 word matching games</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-primary-soft rounded-lg">
                <Trophy className="w-5 h-5 text-primary" />
                <div>
                  <div className="font-semibold text-primary">Level Up!</div>
                  <div className="text-sm text-primary text-dyslexic">Reached Level {level}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Games;