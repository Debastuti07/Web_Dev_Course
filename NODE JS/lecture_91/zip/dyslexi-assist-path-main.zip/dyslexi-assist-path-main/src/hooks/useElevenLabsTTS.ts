import { useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

export interface ElevenLabsVoice {
  voice_id: string;
  name: string;
  category: string;
  description: string;
}

// Top ElevenLabs voices with their IDs
export const ELEVENLABS_VOICES: ElevenLabsVoice[] = [
  { voice_id: "9BWtsMINqrJLrRacOk9x", name: "Aria", category: "Conversational", description: "Warm and friendly" },
  { voice_id: "CwhRBWXzGAHq8TQ4Fs17", name: "Roger", category: "Narrative", description: "Clear and articulate" },
  { voice_id: "EXAVITQu4vr4xnSDxMaL", name: "Sarah", category: "Conversational", description: "Professional and clear" },
  { voice_id: "FGY2WhTYpPnrIDTdsKH5", name: "Laura", category: "Narrative", description: "Expressive and engaging" },
  { voice_id: "IKne3meq5aSn9XLyUdCD", name: "Charlie", category: "Conversational", description: "Youthful and energetic" },
  { voice_id: "JBFqnCBsd6RMkjVDRZzb", name: "George", category: "Narrative", description: "Authoritative and deep" },
  { voice_id: "N2lVS1w4EtoT3dr4eOWO", name: "Callum", category: "Conversational", description: "Gentle and soothing" },
  { voice_id: "SAz9YHcvj6GT2YYXdXww", name: "River", category: "Narrative", description: "Natural and flowing" },
  { voice_id: "TX3LPaxmHKxFdv7VOQHJ", name: "Liam", category: "Conversational", description: "Bright and cheerful" },
  { voice_id: "XB0fDUnXU5powFXDhCwa", name: "Charlotte", category: "Narrative", description: "Sophisticated and warm" },
  { voice_id: "Xb7hH8MSUJpSbSDYk0k2", name: "Alice", category: "Conversational", description: "Crisp and clear" },
  { voice_id: "bIHbv24MWmeRgasZH58o", name: "Will", category: "Narrative", description: "Confident and strong" },
];

export const useElevenLabsTTS = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { toast } = useToast();

  const generateSpeech = async (
    text: string, 
    voiceId: string = "9BWtsMINqrJLrRacOk9x",
    modelId: string = "eleven_turbo_v2_5"
  ): Promise<string | null> => {
    if (!text.trim()) {
      toast({
        title: "No text provided",
        description: "Please enter some text to convert to speech",
        variant: "destructive",
      });
      return null;
    }

    setIsLoading(true);
    
    try {
      console.log(`Generating speech with voice: ${voiceId}`);
      
      const { data, error } = await supabase.functions.invoke('elevenlabs-tts', {
        body: { 
          text: text.trim(),
          voice_id: voiceId,
          model_id: modelId
        }
      });

      if (error) {
        throw new Error(error.message || 'Failed to generate speech');
      }

      if (!data?.audio) {
        throw new Error('No audio data received from ElevenLabs');
      }

      // Create audio URL from base64
      const audioBlob = new Blob(
        [Uint8Array.from(atob(data.audio), c => c.charCodeAt(0))],
        { type: 'audio/mpeg' }
      );
      
      const audioUrl = URL.createObjectURL(audioBlob);
      
      toast({
        title: "Speech generated! 🎵",
        description: "High-quality voice ready to play",
      });

      return audioUrl;
    } catch (error) {
      console.error('ElevenLabs TTS error:', error);
      toast({
        title: "Speech generation failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const playAudio = async (audioUrl: string) => {
    try {
      // Stop any currently playing audio
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }

      // Create new audio element
      const audio = new Audio(audioUrl);
      audioRef.current = audio;

      audio.onloadstart = () => {
        setIsPlaying(true);
        toast({
          title: "Playing ElevenLabs voice! 🔊",
          description: "Enjoy the high-quality AI speech",
        });
      };

      audio.onended = () => {
        setIsPlaying(false);
        toast({
          title: "Playback finished! ✨",
          description: "Ready for more text-to-speech",
        });
      };

      audio.onerror = () => {
        setIsPlaying(false);
        toast({
          title: "Playback error",
          description: "Failed to play the audio",
          variant: "destructive",
        });
      };

      await audio.play();
    } catch (error) {
      setIsPlaying(false);
      console.error('Audio playback error:', error);
      toast({
        title: "Playback failed",
        description: "Could not play the generated audio",
        variant: "destructive",
      });
    }
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
      toast({
        title: "Playback stopped",
        description: "Ready for new audio",
      });
    }
  };

  const speakWithElevenLabs = async (
    text: string, 
    voiceId?: string,
    modelId?: string
  ) => {
    const audioUrl = await generateSpeech(text, voiceId, modelId);
    if (audioUrl) {
      await playAudio(audioUrl);
    }
  };

  return {
    isLoading,
    isPlaying,
    generateSpeech,
    playAudio,
    stopAudio,
    speakWithElevenLabs,
    voices: ELEVENLABS_VOICES
  };
};