import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-3 whitespace-nowrap rounded-xl text-base font-display font-semibold transition-all duration-300 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-primary focus-visible:ring-offset-3 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-5 [&_svg]:shrink-0 shadow-soft hover:shadow-medium active:scale-95",
  {
    variants: {
      variant: {
        default: "bg-gradient-primary text-primary-foreground hover:shadow-glow hover:scale-105 active:scale-95",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90 hover:scale-105",
        outline: "border-2 border-primary bg-background text-primary hover:bg-primary hover:text-primary-foreground hover:scale-105",
        secondary: "bg-gradient-warm text-secondary-foreground hover:scale-105 hover:shadow-medium",
        success: "bg-gradient-success text-accent-foreground hover:scale-105 hover:shadow-glow",
        ghost: "hover:bg-primary-soft hover:text-primary hover:scale-105",
        link: "text-primary underline-offset-4 hover:underline p-0 h-auto shadow-none hover:shadow-none",
        playful: "bg-secondary-warm text-secondary-foreground hover:bg-secondary hover:scale-110 hover:rotate-1 transition-all duration-300 shadow-medium hover:shadow-strong",
        gentle: "bg-primary-soft text-primary border-2 border-primary/20 hover:border-primary/40 hover:bg-primary/10 hover:scale-105"
      },
      size: {
        default: "h-12 px-6 py-3",
        sm: "h-10 rounded-lg px-4 py-2",
        lg: "h-14 rounded-xl px-8 py-4 text-lg",
        xl: "h-16 rounded-2xl px-10 py-5 text-xl",
        icon: "h-12 w-12",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
